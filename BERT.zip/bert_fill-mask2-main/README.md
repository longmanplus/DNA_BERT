
run python ./train.py or python ./train.py --nnodes 1
